
main :: IO() -- Declaración de firma o tipo
main = do
    putStrLn "Hello EAFIT"
    let a = 14
    let b = 7
    print(a + b)
    putStrLn $ show(a + b)
    print(a * b)
    print(a / b)
