-- Una función se crea o se declara con la forma:
-- nombreFuncion parametro1 parametro ... parametroN = cuerpoFuncion

-- Funciones puras: A la(s) entrada(s) siempre le(s) corresponde la misma salida

doble x = x + x

cuadrado x = x * x

sumaDos :: Integer -> Integer -> Integer -- Declaración de firma o tipo
sumaDos x y = x + y

-- Estructura condicional
esPar :: Integer -> String
esPar x = 
    if mod x 2 == 0
        then "El valor ingresado es par"
    else "El valor ingresado es impar"

esParBool :: Int -> Bool
esParBool x = x `mod` 2 == 0 -- La función mod está escrita de forma infija


-- Funciones de orden superior: Son fucniones que reciben una función como
-- parámetro, bien sea en la entrada o en la salida.
definirPares xy = map esParBool xy -- La función de orden superior es map

filtrarPares xy = filter esParBool xy 

main :: IO() -- Declaración de firma o tipo
main = do
    putStrLn "Hello EAFIT"
    let a = 15
    let b = 6
    let suma = a + b
    print(suma)
    putStrLn $ show(a + b)
    print(a * b)
    --print(a / b)
    --print(div a b)
    -- Generadores de listas
    print([1..10])
    print([2,4..10])
    print([3,6..30])
    print([10,9..1])
    print(take 3 [0..])
    print(take 3 (drop 5 [0..]))
    print(doble a)
    print(cuadrado a)
    print(sumaDos a b)
    putStrLn $ show(esPar b)
    print(definirPares [1..5])
    print(filtrarPares [1..5])    